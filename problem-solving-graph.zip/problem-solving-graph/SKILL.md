---
name: problem-solving-graph
description: Persistent visual tracking of problem-solving sessions. Records strategic outcomes, facts, hypotheses, divergences, and their relationships. Integrates with scientific-problem-solving methodology to create an explorable map of the investigation.
---

# Problem-Solving Graph Skill

## Core Mandate

**Augment the scientific-problem-solving process with persistent, visual memory.** Every significant node in the exploration—facts established, hypotheses developed, divergences taken, statistical checks performed—gets captured in a graph structure that survives across conversations.

This solves three critical problems:
1. **LLM memory limitations** - graph persists between sessions
2. **Lost context** - always know where we are in the process
3. **Documentation burden** - graph auto-documents the exploration

## When to Use This Skill

**Always use when:**
- Starting a complex problem-solving conversation
- Working across multiple sessions
- High chance of divergences and rabbit holes
- Need to track facts vs conjectures vs hypotheses
- Want to visualize the exploration path

**Don't use for:**
- Simple, single-session questions
- Quick clarifications
- Casual conversation

## Integration with Scientific Problem-Solving

This skill **enhances** scientific-problem-solving, it doesn't replace it. The rhythm is:

```
User: [asks complex question]
You: [thinking: This is complex, will span sessions, needs graph]
     [call: init_session]
     [proceed with scientific-problem-solving dialogue]
     [at natural checkpoints: update graph]
```

## The MCP Server

You have access to a `problem-solving-graph` MCP server with these tools:

- `init_session(session_name, strategic_outcome)` - Start new session
- `add_node(session_name, node)` - Add fact, hypothesis, divergence, etc.
- `add_edge(session_name, edge)` - Connect nodes with relationships
- `update_node(session_name, update)` - Add observations to existing node
- `get_graph(session_name, format)` - See current state
- `generate_view(session_name)` - Create HTML visualization
- `list_sessions()` - See all sessions

## Workflow Integration

### Phase 0: Strategic Context

**Start of conversation:**
```
1. Recognize this needs persistent tracking
2. init_session(session_name, strategic_outcome)
3. Proceed with natural strategic context dialogue
```

The session is created with a Strategic Outcome node. You don't need to add it separately.

### Phase 1: Diagnostic Dialogue

**As you establish facts:**
```
User: "Current conversion rate is 2.3% from GA"
You: [acknowledge]
     [add_node(type="Fact", label="Current conversion: 2.3%", 
               observations=["From Google Analytics", "Last 30 days, 10K visitors"])]
     [continue dialogue]
```

**When surfacing biases:**
```
You: "That's a self-selected sample. People who respond might differ from those who don't. Does that matter for your decision?"
    [add_node(type="Statistical Check", label="Selection bias in survey data",
              observations=["Self-selected sample", "Responders may differ from non-responders"])]
    [add_edge(from="stat-check-1", to="fact-X", type="questions validity of")]
```

**Key principle:** Add nodes at natural checkpoints, not after every sentence. When something significant is established, capture it.

### Phase 2: Root Cause Analysis

**When divergences emerge:**
```
User: "What if the problem is actually upstream traffic quality?"
You: "Interesting divergence - let's explore that."
     [add_node(type="Insight Thread", label="Maybe upstream traffic quality?",
               observations=["Emerged from paid vs organic discussion",
                            "Paid traffic converts at 1.5% vs organic 2.8%"])]
     [add_edge(from="divergence-1", to="fact-X", type="emerged from")]
     [continue exploration]
```

**When establishing hypotheses:**
```
You: "So we have a hypothesis: Value proposition is unclear."
     [add_node(type="Hypothesis", label="Value prop is unclear",
               observations=["Headline too vague", "Users don't understand benefit"])]
     [add_edge(from="hypothesis-1", to="outcome-1", type="potential root cause of")]
```

**When tracing Nth order effects:**
```
You: "Let's trace this: Less form friction → more signups → BUT potentially lower quality leads?"
     [add_node(type="Nth Order Effect", label="Form friction reduces quality signals",
               observations=["Less friction = more volume", "But sales team might get bad leads"])]
     [add_edge(from="nth-order-1", to="hypothesis-2", type="reveals risk in")]
```

### Phase 3: Hypothesis Generation

**Classify each claim:**
```
You: "OK, so we know [FACT] because [evidence]"
     [add_node(type="Fact", ...)]

You: "We think [CONJECTURE] - we could test by..."
     [add_node(type="Conjecture", ...)]

You: "You're betting [HYPOTHESIS] - reasonable given X, but we'd learn by doing"
     [add_node(type="Hypothesis", ...)]
```

**Connect supporting evidence:**
```
[add_edge(from="conjecture-1", to="hypothesis-1", type="supports")]
```

### Phase 4: Validation Framework

**As validation methods are designed:**
```
You: "Option A: 5-second test - $200, 2 days, establishes if messaging is the issue"
     [add_node(type="Validation Method", label="5-second test for value prop",
               observations=["Cost: $200", "Time: 2 days", "Tests messaging clarity"])]
     [add_edge(from="validation-1", to="conjecture-1", type="tests")]
```

### Phase 5: Path Forward

**Before ending session:**
```
[generate_view(session_name)]

You: "I've created a visual map of our exploration: [path to view.html]
     
     We established X facts, explored Y divergences, developed Z hypotheses.
     Next time we pick this up, we'll have this entire context."
```

## Node Types Reference

- **Strategic Outcome** - What we're ultimately trying to achieve
- **Fact** - Established, verified, observable truth
- **Conjecture** - Testable with reasonable effort (experiment design exists)
- **Hypothesis** - Requires action to validate (may need leap of faith)
- **Insight Thread** - Divergence or rabbit hole exploration
- **Validation Method** - How to test a claim (with timeline, cost, tradeoffs)
- **Statistical Check** - Bias identification, rigor validation
- **Open Question** - Unresolved uncertainty or break point
- **Nth Order Effect** - Causal chain or downstream impact

## Edge Types Reference

Common relationship types:
- "supports" - Evidence supports a claim
- "tests" - Validation method tests hypothesis/conjecture
- "emerged from" - Divergence arose from exploration
- "challenges" / "questions validity of" - Node raises doubts
- "traces causal chain from" - Nth order effect follows from
- "provides context for" - Background information
- "reveals problem from" - Discovery from investigation
- "potential root cause of" - Hypothesis explains outcome
- "connects back to" - Divergence loops back to main thread
- "informs solution for" - Insight contributes to answer

## Natural Update Rhythm

**Don't interrupt the flow.** Update the graph at natural breakpoints:

✅ **Good times to update:**
- Fact is established through evidence
- Hypothesis is formally stated
- Divergence is recognized as such
- Statistical check surfaces a bias
- Validation method is designed
- Phase transition (diagnostic → root cause)
- End of conversation

❌ **Don't update for:**
- Every user message
- Mid-dialogue while exploring
- Casual back-and-forth
- Clarifying questions

## Handling Multiple Sessions

**Returning to a session:**
```
User: "Let's continue that conversion optimization work"
You: [get_graph(session_name, format="summary")]
     [review the summary]
     "We left off exploring [X]. We had established [facts], developed [hypotheses].
      Where do you want to continue?"
```

**Starting related work:**
```
You might create a new session if:
- Completely different problem
- Different strategic outcome
- Weeks/months have passed

You continue existing session if:
- Same problem, more exploration
- Testing hypotheses developed earlier
- Following up on validation results
```

## Metadata Best Practices

**Include in node metadata:**
- `phase`: "strategic-context", "diagnostic-dialogue", "root-cause", etc.
- `confidence`: "high", "medium", "low"
- `timestamp`: auto-added if not provided

**Example:**
```python
metadata={
    "phase": "diagnostic-dialogue",
    "confidence": "high",
    "source": "Google Analytics",
    "date_collected": "2025-11-09"
}
```

## Graph Maintenance

**Regenerate visualization:**
After significant updates, regenerate the HTML:
```
[generate_view(session_name)]
```

This creates a fresh view.html with current graph state.

**Check graph state:**
Use `get_graph(format="summary")` to see structure without leaving dialogue flow.

## Critical Reminders

1. **The graph augments dialogue, doesn't replace it.** Still follow scientific-problem-solving rhythm: ask, wait, acknowledge, think aloud.

2. **Update at natural checkpoints.** Don't break conversational flow to update graph after every exchange.

3. **Facts/Conjectures/Hypotheses classification still happens in dialogue.** The graph just records it persistently.

4. **Divergences are valuable.** When rabbit holes emerge, capture them as "Insight Thread" nodes and show how they connect back.

5. **The graph is for BOTH of us.** It helps me remember context across sessions, and gives you a visual map of the exploration.

6. **Always provide the view.html path** at natural breakpoints so user can visualize progress.

## Example Integration

```
User: "I want to improve conversion rate on my landing page"

You: [thinking: Complex, will take multiple sessions, needs tracking]
     Let me set up a problem-solving graph for this. It'll help us track 
     our exploration across sessions.
     
     [init_session("conversion-optimization-nov-2025", 
                   "Improve landing page conversion rate")]
     
     Great! I've initialized our session. Now, what's the ultimate business 
     outcome you're trying to achieve? How does conversion rate tie into that?

User: "Current rate is 2.3%, I want to get to 4%"

You: Got it. So strategic outcome is reaching 4% conversion.
     [add_node(type="Fact", id="fact-1", label="Current: 2.3%, Target: 4%",
               observations=["Would mean 80 extra trials/month"])]
     [add_edge(from="fact-1", to="outcome-1", type="establishes baseline for")]
     
     And what happens if you get those 80 extra trials? Walk me through 
     the business impact...
     
     [continue natural scientific-problem-solving dialogue]
     [update graph at checkpoints]
```

## Success Criteria

A successful use of this skill means:

1. **Session initialized** at start of complex problem-solving
2. **Key nodes captured** (facts, hypotheses, divergences) at natural points
3. **Relationships tracked** showing how pieces connect
4. **User gets view.html link** to see the exploration map
5. **Next session can resume** with full context from graph
6. **Divergences are visible** showing non-linear exploration path

The graph should feel like **augmented memory** - helpful scaffolding that doesn't interrupt the natural problem-solving dialogue.
